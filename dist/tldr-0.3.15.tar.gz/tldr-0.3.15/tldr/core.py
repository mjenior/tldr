import os
import asyncio

from openai import OpenAI, AsyncOpenAI

from tldr.i_o import (
    create_timestamp,
    fetch_content,
    read_system_instructions,
    save_response_text,
    generate_tldr_pdf,
)
from tldr.completion import CompletionHandler


class TldrClass(CompletionHandler):
    """
    Main TLDR class
    """

    def __init__(
        self,
        search_directory=".",
        output_directory=".",
        context_directory=None,
        recursive_search=False,
        verbose=True,
        api_key=None,
        token_scale="medium",
    ):
        # Set basic attr
        self.verbose = verbose
        self.token_scale = token_scale
        self.recursive_search = recursive_search
        self.user_query = ""
        self.added_context = ""

        # Read in system instructions
        self.instructions = read_system_instructions()

        # Establish output directory
        self.output_directory = self._handle_output_path(output_directory, verbose)

        # Set API key
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key not provided.")

        # Initialize OpenAI clients
        self.client = AsyncOpenAI(api_key=self.api_key)

        # Read in files and contents
        if self.verbose == True:
            print("Searching for input files...")
        self.content = fetch_content(search_directory, recursive=self.recursive_search)
        self.sources = sum([len(self.content[x]) for x in self.content.keys()])

        # Fetch additional context if provided
        if context_directory is not None:
            raw_context = fetch_content(
                context_directory, combine=True, recursive=self.recursive_search
            )
            context_report = f", and {len(raw_context)} context documents"
            added_context = self.single_completion(
                message="\n".join(raw_context), prompt_type="format_context"
            )
            save_response_text(
                added_context,
                label="added_context",
                output_dir=self.output_directory,
                verbose=self.verbose,
            )
            self.added_context += f"\nBelow is additional context for reference during response generation:\n{added_context}"
        else:
            context_report = ""

        if self.verbose == True:
            print(f"Identified {self.sources} reference documents{context_report}.\n")

    def __call__(self, query=None):
        """
        More streamlined, callable interface to run the main TLDR pipeline.

        Arguments:
        - query: user query for focused summary context
        """

        async def _pipeline():

            # Update user query
            if query is not None:
                self.user_query = await self.refine_user_query(query)

            # Generate async summaries
            self.all_summaries = await self.summarize_resources()

            # Integrate summaries
            if len(self.all_summaries) >= 2:
                await self.integrate_summaries()
            else:
                self.content_synthesis = self.all_summaries[0]

            # Apply research if needed
            await self.apply_research(context_size=self.token_scale)

            # Polish the final result
            await self.polish_response()

        # Run the async pipeline
        asyncio.run(_pipeline())

    @staticmethod
    def _handle_output_path(output_path, verbose=True) -> str:
        """Set up where to write output summaries"""

        # Create full path for intermediate files
        temp_path = os.path.join(
            output_path, f"tldr.{create_timestamp()}", "intermediate"
        )
        os.makedirs(temp_path, exist_ok=True)

        # Return top level new directory
        new_path = os.path.join(output_path, f"tldr.{create_timestamp()}")

        if verbose == True:
            print("\nOutput files being written to:", new_path)

        return new_path

    @staticmethod
    def _lint_user_query(current_query) -> None:
        """
        Normalizes user query to ensure it's a well formed string.
        """

        # Handle list input or convert to string
        if isinstance(current_query, list):
            processed_query = " ".join(map(str, current_query))
        elif isinstance(current_query, str):
            processed_query = current_query
        elif current_query is None:
            processed_query = ""
        else:
            processed_query = str(current_query)

        # Capitalize the first letter (if the string is not empty)
        if processed_query:  # Check if the string is not empty
            processed_query = processed_query[0].upper() + processed_query[1:]

        # Ensure the query ends with a question mark (if the string is not empty)
        if processed_query and not processed_query[-1] not in [".", "!", "?"]:
            processed_query += "?"
        elif not processed_query:
            pass

        return processed_query

    def refine_user_query(self, query):
        """Attempt to automatically improve user query for greater specificity"""

        if self.verbose == True:
            print("Refining user query...")

        # Check text formatting
        user_query = self._lint_user_query(query)

        # Generate new query text
        new_query = self.single_completion(
            message=user_query, prompt_type="refine_prompt"
        )

        # Handle output text
        full_query = f"Ensure that addressing the following user query is the key consideration in you response:\n{new_query}\n"
        save_response_text(
            new_query,
            label="new_query",
            output_dir=self.output_directory,
            verbose=self.verbose,
        )
        if self.verbose == True:
            print(f"Refined query:\n{new_query}\n")

        return full_query

    async def summarize_resources(self):
        """Generate component and synthesis summary text"""

        # Asynchronously summarize documents
        if self.verbose == True:
            print("Generating summaries for selected resources...")
        summaries = await self.multi_completions()
        await self.client.close()

        # Join response strings
        all_summaries = []
        for i in range(0, len(summaries)):
            all_summaries.append(f"Reference {i+1} Summary\n{summaries[i]}\n")
        save_response_text(
            all_summaries,
            label="summary",
            output_dir=self.output_directory,
            verbose=self.verbose,
        )

        return all_summaries

    def integrate_summaries(self):
        """Generate integrated executive summaries combine all current summary text"""
        if self.verbose == True:
            print("Generating integrated summary text...")

        # Join all summaries for one large submission
        summaries = "\n\n".join(self.all_summaries)
        synthesis = self.single_completion(
            message=summaries, prompt_type="executive_summary"
        )

        # Handle output
        save_response_text(
            synthesis,
            label="synthesis",
            output_dir=self.output_directory,
            verbose=self.verbose,
        )
        self.content_synthesis = synthesis

    def apply_research(self, context_size="medium"):
        """Identify knowledge gaps and use web search to fill them. Integrating new info into summary."""

        # Identify gaps in understanding
        if self.verbose == True:
            print("\rIdentifying technical gaps in summary...")
        gap_questions = self.single_completion(
            message=self.content_synthesis, prompt_type="research_instructions"
        )

        # Search web for to fill gaps
        if self.verbose == True:
            print("\rResearching gaps in important background...")
        research_results = self.search_web(gap_questions, context_size=context_size)

        # Handle output
        research_text = (
            f"Gap questions:\n{gap_questions}\n\nAnswers:\n{research_results}"
        )
        save_response_text(
            research_text,
            label="research",
            output_dir=self.output_directory,
            verbose=self.verbose,
        )

        # Add to extra context
        self.added_context += research_results

    def polish_response(self, tone: str = "default"):
        """Refine final response text"""
        if self.verbose == True:
            print("Finalizing response text...")

        # Select tone
        tone_instructions = (
            "polishing_instructions" if tone == "default" else "modified_polishing"
        )
        response_text = self.user_query + self.content_synthesis

        # Run completion and save final response text
        polished_text = self.single_completion(
            message=self.content_synthesis, prompt_type=tone_instructions
        )
        polished_title = self.single_completion(
            message=polished_text, prompt_type="title_instructions"
        )

        # Save formatted PDF
        output_file = generate_tldr_pdf(
            polished_text, polished_title, self.output_directory
        )

        # Print final answer to terminal
        if self.verbose == True:
            print(f"\n\n{polished}\n")
