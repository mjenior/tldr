#!/usr/bin/env python3

import sys
import argparse
import asyncio
from tldr.core import TldrClass


def parse_user_arguments():
    """Parses command-line arguments"""
    parser = argparse.ArgumentParser(
        description="TLDR: Summarize text files based on user arguments."
    )

    # Define arguments
    parser.add_argument("query", nargs="?", default="", help="Optional user query")
    parser.add_argument(
        "-i",
        "--input_directory",
        default=".",
        help="Directory to scan for text files (Default is working directory)",
    )
    parser.add_argument(
        "-o",
        "--output_directory",
        default=".",
        help="Directory for output files (Default is working directory)",
    )
    parser.add_argument(
        "-r",
        "--refine_query",
        type=bool,
        default=True,
        help="Automatically refine and improve the user query",
    )
    parser.add_argument(
        "-c",
        "--context_directory",
        default=None,
        help="Directory for additional context documents",
    )
    parser.add_argument(
        "-u",
        "--recursive_search",
        type=bool,
        default=False,
        help="Recursively search input directories",
    )
    parser.add_argument(
        "-x",
        "--research",
        type=bool,
        default=True,
        help="Additional research agent to find and fill knowledge gaps",
    )
    parser.add_argument(
        "-s",
        "--context_size",
        type=str,
        default="medium",
        choices=["low", "medium", "high"],
        help="Context window size for research agent web search",
    )
    parser.add_argument(
        "-n",
        "--tone",
        choices=["default", "modified"],
        default="default",
        help="Final executive summary response tone",
    )
    parser.add_argument(
        "-t",
        "--token_scale",
        type=str,
        choices=["low", "medium", "high"],
        default="medium",
        help="Modifier for scale of maximum output tokens window",
    )
    parser.add_argument(
        "-v", "--verbose", type=bool, default=True, help="Verbose stdout reporting"
    )

    return parser.parse_args()


def main():
    """Main entry point for the tldr command"""
    # Read in command line arguments
    args = parse_user_arguments()

    # Read in content and extend user query
    tldr = TldrClass(
        search_directory=args.input_directory,
        output_directory=args.output_directory,
        context_directory=args.context_directory,
        recursive_search=args.recursive_search,
        verbose=args.verbose,
        token_scale=args.token_scale,
    )

    # Check if no resources were found
    if tldr.sources == 0:
        sys.exit(1)

    # Extend user query
    if len(args.query) > 0:
        tldr.user_query = (
            tldr.refine_user_query(args.query)
            if args.refine_query == True
            else args.query
        )

    # Summarize documents
    tldr.all_summaries = asyncio.run(tldr.summarize_resources())

    # Synthesize content
    if len(tldr.all_summaries) >= 2:
        tldr.integrate_summaries()
    else:
        tldr.content_synthesis = tldr.all_summaries[0]

    # Use research agent to fill gaps
    if args.research:
        tldr.apply_research(context_size=args.context_size)

    # Rewrite for response type and tone
    tldr.polish_response(args.tone)


if __name__ == "__main__":
    main()
