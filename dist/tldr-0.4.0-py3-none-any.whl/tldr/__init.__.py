from tldr.core import TldrClass
from tldr.tldr import main

__all__ = ["TldrClass", "main"]
