#!/usr/bin/env python3

import sys
import argparse
import asyncio
from .core import TldrClass


def parse_user_arguments():
    """Parses command-line arguments"""
    parser = argparse.ArgumentParser(
        description="TLDR: Summarize text files based on user arguments."
    )

    # Define arguments
    parser.add_argument("query", nargs="?", default="", help="Optional user query")
    parser.add_argument(
        "-i",
        "--input_directory",
        default=".",
        help="Directory to scan for text files (Default is working directory)",
    )
    parser.add_argument(
        "-o",
        "--output_directory",
        default=".",
        help="Directory for output files (Default is working directory)",
    )
    parser.add_argument(
        "-r",
        "--refine_query",
        type=bool,
        default=True,
        help="Automatically refine and improve the user query",
    )
    parser.add_argument(
        "-c",
        "--context_directory",
        default=None,
        help="Directory for additional context documents",
    )
    parser.add_argument(
        "-s",
        "--recursive_search",
        type=bool,
        default=False,
        help="Recursively search input directories",
    )
    parser.add_argument(
        "-x",
        "--research",
        type=bool,
        default=True,
        help="Additional research agent to find and fill knowledge gaps",
    )
    parser.add_argument(
        "-n",
        "--tone",
        choices=["default", "modified"],
        default="default",
        help="Final executive summary response tone",
    )
    parser.add_argument(
        "-t",
        "--token_scale",
        type=str,
        choices=["low", "medium", "high"],
        default="medium",
        help="Modifier for scale of maximum output tokens and context window size for research agent web search",
    )
    parser.add_argument(
        "-v", "--verbose", type=bool, default=True, help="Verbose stdout reporting"
    )

    return parser.parse_args()


async def main():
    """Main entry point for the tldr command"""

    # Read in command line arguments
    args = parse_user_arguments()

    # Read in content and extend user query
    tldr = TldrClass(
        search_directory=args.input_directory,
        output_directory=args.output_directory,
        context_directory=args.context_directory,
        recursive_search=args.recursive_search,
        verbose=args.verbose,
        token_scale=args.token_scale,
    )

    # Check if no resources were found
    if tldr.sources == 0:
        sys.exit(1)

    # Extend user query
    if len(args.query) > 0 and args.refine_query == True:
        tldr.user_query = await tldr.refine_user_query(args.query)
    else:
        tldr.user_query = ""

    # Condense any context docs provided
    if tldr.raw_context is not None:
        await tldr.format_context_references()
    else:
        tldr.added_context = ""

    # Summarize documents
    tldr.all_summaries = await tldr.summarize_resources()

    # Synthesize content
    if len(tldr.all_summaries) >= 2:
        await tldr.integrate_summaries()
    else:
        tldr.content_synthesis = tldr.all_summaries[0]

    # Use research agent to fill gaps
    if args.research:
        await tldr.apply_research(context_size=args.context_size)

    # Rewrite for response type and tone
    await tldr.polish_response(args.tone)


def async_main():
    asyncio.run(main())


if __name__ == "__main__":
    asyncio.run(main())
