"""
This module contains the core logic for generating TLDR summaries.

It provides a class, TldrEngine, which is responsible for processing input files,
fetching additional context, performing Retrieval Augmented Generation (RAG)
using local embeddings, refining user queries, and generating summaries based on the
provided information. It manages interactions with a completion API and handles the
output of intermediate and final results.
"""

import re
import asyncio
from .openai import CompletionHandler


class TldrEngine(CompletionHandler):
    """
    Handles the core logic for generating TLDR summaries.

    This class is responsible for processing input files, fetching additional context,
    optionally performing Retrieval Augmented Generation (RAG) using local embeddings,
    refining user queries, and generating summaries based on the provided information.
    It manages interactions with a completion API and handles the output of
    intermediate and final results.

    Attributes:
        recursive (bool): Whether to search for input files recursively in directories.
        verbose (bool): If True, enables detailed logging.
        api_key (str, optional): The API key for the completion service.
        context_size (str): Specifies the context window size for the model (e.g., "small", "medium", "large").
        tag (str): A tag for the current run, used for naming output directories.
        output_directory (str): The path to the directory where intermediate and final files are saved.
        content (list[str]): A list of strings, where each string is the content of an input file.
        query (str): The user's query to be addressed by the summary.
        added_context (str): Formatted additional context to be used in prompts.
    """

    def __init__(
        self,
        verbose=True,
        api_key=None,
    ):
        # Initialize parent class chain
        super().__init__(api_key=api_key)

        # Additional attributes
        self.verbose = verbose
        self.random_seed = 42
        self.content = None
        self.query = None
        self.added_context = ""
        self.platform = "openai"

        # Initialize session
        self._generate_run_tag()
        self._create_output_path()
        self._start_logging()
        self._read_system_instructions()
        self._new_openai_client()

    async def load_all_content(
        self,
        input_files=None,
        context_files=None,
        context_size="medium",
        recursive=False,
    ):
        """Establish context for the TldrEngine"""

        # Read in files and contents
        if input_files is not None:
            self.content = self.fetch_content(user_files=input_files, label="reference")
        else:
            self.content = self.fetch_content(recursive=recursive, label="reference")

        # Fetch and reformat additional context if provided
        if context_files is not None and context_files != []:
            all_context = self.fetch_content(user_files=context_files, label="context")
            await self.format_context(
                "".join(all_context), context_size=context_size, label="context_files"
            )

        # Create embeddings
        await self._create_embeddings(context_size=context_size)

    async def _create_embeddings(self, context_size="medium", platform="openai"):
        """Create local embeddings for reference documents"""

        # Create local embeddings
        self.encode_text_to_vector_store(platform=platform)

        # Search for added initial context
        if self.query is not None and self.query != "":
            context_search = self.search_embedded_context(query=self.query)
            await self.format_context(
                context_search, context_size=context_size, label="context_search"
            )

    async def finish_session(self):
        """Complete run with stats reporting"""
        result = self.save_response_text(self.added_context, label="full_context")
        self.logger.info(f"Response saved to: {result}")
        self.format_spending()
        self.generate_token_report()
        await self.client.close()

    async def format_context(
        self, new_context, context_size="medium", label="formatted_context"
    ):
        """
        Creates more concise, less repetative context message
        """
        # Format context references
        formatted_context = await self.perform_api_call(
            prompt=new_context,
            prompt_type="format_context",
            context_size=context_size,
            web_search=False,
        )
        self.added_context += formatted_context["response"]
        result = self.save_response_text(
            formatted_context["response"],
            label=label,
        )
        self.logger.info(f"Response saved to: {result}")

    def _lint_query(self, query) -> str:
        """
        Normalizes user query to ensure it's more well-formed & AI-friendly
        """
        # Normalize input to string
        if isinstance(query, list):
            processed_query = " ".join(map(str, query)).strip()
        else:
            processed_query = str(query).strip()

        # Ensure it ends with a suitable punctuation mark
        if processed_query[-1] not in ".!?":
            processed_query += "?"

        return processed_query

    async def refine_user_query(self, query, context_size="medium"):
        """
        Automatically improve user query for greater specificity
        """
        if query is None or query.strip() == "":
            self.query = ""
            return
        else:
            self.logger.info("Refining user query...")

        # Generate new query text
        refined_query = await self.perform_api_call(
            prompt=self._lint_query(query),
            prompt_type="refine_prompt",
            context_size=context_size,
            web_search=False,
        )

        # Handle output text
        self.query = refined_query["response"]
        self.logger.info(f"Refined query: {self.query}")
        result = self.save_response_text(self.query, label="refined_query")
        self.logger.info(f"Response saved to: {result}")

        self.logger.info(f"Finished refining user query")
        

    async def summarize_resources(self, context_size="medium"):
        """Generate component and synthesis summary text"""
        self.logger.info("Generating summaries for selected resources...")

        # Asynchronously summarize documents
        reference_summaries = await self.multi_completions(
            content_dict=self.content, context_size=context_size
        )

        # Annotate and save response strings
        all_summaries = []
        for i, summary in enumerate(reference_summaries):
            self.content[summary["source"]]["summary"] = summary["response"]
            all_summaries.append(f"Reference {i} Summary:\n{summary['response']}\n")
        self.all_summaries = "\n\n".join(all_summaries)
        result = self.save_response_text(
            self.all_summaries, label="reference_summaries"
        )
        self.logger.info(f"Response saved to: {result}")

        self.logger.info(f"Finished summarizing resources")

    async def integrate_summaries(self, context_size="medium"):
        """Generate integrated executive summary text"""
        self.logger.info("Generating integrated summary text...")

        # Generate executive summary
        executive_summary = await self.perform_api_call(
            prompt=self.all_summaries,
            prompt_type="executive_summary",
            context_size=context_size,
            web_search=False,
        )
        self.executive_summary = executive_summary["response"]

        # Handle output
        result = self.save_response_text(
            executive_summary["response"], label="executive_summary"
        )
        self.logger.info(f"Response saved to: {result}")

        self.logger.info(f"Finished integrating summaries")

    async def polish_response(self, tone="stylized", context_size="medium"):
        """Refine final response text"""
        self.logger.info("Finalizing response text...")

        # Select tone
        tone_instructions = (
            "formal_polishing" if tone == "formal" else "stylized_polishing"
        )

        # Polish summary
        self.polished_summary = await self.perform_api_call(
            prompt=self.executive_summary,
            prompt_type=tone_instructions,
            context_size=context_size,
            web_search=False,
        )
        self.polished_summary = self.polished_summary["response"]
        result = self.save_response_text(
            self.polished_summary,
            label="polished_summary",
        )
        self.logger.info(f"Response saved to: {result}")

        self.logger.info(f"Finished polishing response")

    async def save_to_pdf(self, smart_title=True, polished=True):
        """Saves polished summary string to formatted PDF document."""
        self.logger.info("Saving final summary to PDF...")
        summary_text = (
            self.polished_summary if polished is True else self.executive_summary
        )

        # Generate title
        if smart_title is True:
            doc_title = await self.perform_api_call(
                prompt=summary_text,
                prompt_type="title_instructions",
                context_size="low",
                web_search=False,
            )

        # Save to PDF
        pdf_path = self.generate_tldr_pdf(
            summary_text=summary_text,
            doc_title=doc_title["response"],
        )
        self.logger.info(f"Final summary saved to {pdf_path}")

    async def determine_prompt_type(self, text, filename=None, web_search=False):
        """Determine type of submission"""
        if web_search is False:
            self.logger.info(f"Determining file type of {filename}...")
            source_type = await self.perform_api_call(
                prompt=text,
                prompt_type="file_type",
                web_search=web_search,
            )
            self.logger.info(f"File type determined: {source_type['response']}")
            file_type = re.sub(r"[^a-zA-Z]", "", source_type["response"].lower())
            return file_type
        else:
            return "web_search"

    async def multi_completions(
        self,
        content_dict,
        context_size="medium",
        web_search=False,
        **kwargs,
    ):
        """
        Runs multiple completion calls concurrently.
        """
        # Parse all of the content found
        coroutine_tasks = []
        for source in content_dict.keys():

            # Determine type of submission
            content = content_dict[source]["content"]
            prompt_type = await self.determine_prompt_type(content, source, web_search)

            # Generate summary task
            task = self.perform_api_call(
                prompt=content,
                prompt_type=prompt_type,
                web_search=web_search,
                context_size=context_size,
                source=source,
                **kwargs,
            )
            coroutine_tasks.append(task)

        return await asyncio.gather(*coroutine_tasks, return_exceptions=False)

    async def apply_research(self, context_size="medium"):
        """
        Identify knowledge gaps and use web search to fill them.
        """
        self.logger.info("Identifying knowledge gaps...")
        research_questions = await self.perform_api_call(
            prompt=self.all_summaries,
            prompt_type="background_gaps",
            context_size=context_size,
            web_search=False,
        )

        # Reassemble research questions into content dictionary
        research_questions = research_questions["response"].split("\n")
        research_question_dict = {}
        for i, question in enumerate(research_questions):
            question = question.strip().lstrip("-").lstrip("•").strip()
            research_question_dict[f"Question_{i}"] = {"content": question}

        # Search web for to fill gaps
        self.logger.info("Applying web research agent to knowledge gaps...")
        self.research_results = await self.multi_completions(
            content_dict=research_question_dict,
            context_size=context_size,
            web_search=True,
        )

        # Also search for additional context missed in references
        self.logger.info("Searching for additional context in reference docs...")
        research_context = []
        for q_ans_pair in self.research_results:
            self.logger.info(f"Potential knowledge gap: {q_ans_pair['prompt']}")
            search_context = self.search_embedded_context(
                query=q_ans_pair["prompt"], num_results=1
            )
            search_context = "\n".join(search_context)
            current_context = f'Question:\n{q_ans_pair["prompt"]}\n'
            current_context += f'Answer:\n{q_ans_pair["response"]}\n'
            current_context += f"Local RAG Context:\n{search_context}\n"
            research_context.append(current_context)

        # Assemble full research context
        divider = "\n#--------------------------------------------------------#\n"
        research_str = divider.join(research_context)
        self.research_context = research_str

        # Update added context with new research
        await self.format_context(research_str, label="research_context")
        result = self.save_response_text(research_str, label="research_results")
        self.logger.info(f"Response saved to: {result}")

        self.logger.info(f"Finished research knowledge gaps")
