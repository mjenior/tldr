# tldr

A powerful text summarization tool that uses OpenAI's models to generate concise summaries and evaluations of scientific documents.

## Overview

`tldr` is a Python package designed to help researchers, scientists, and knowledge workers quickly extract key information from scientific publications and technical documents. It uses OpenAI's language models to:

1. Scan and process multiple document types (PDF, DOCX, HTML, TXT)
2. Generate detailed summaries of each document
3. Synthesize information across multiple documents
4. Perform additional research to fill knowledge gaps
5. Create polished, comprehensive responses to user queries

## Features

- **Multi-format document support**: PDF, DOCX, HTML, and TXT files
- **Intelligent query refinement**: Automatically improves user queries
- **Document summarization**: Creates detailed summaries of scientific publications and technical documents
- **Cross-document synthesis**: Integrates information across multiple sources
- **Knowledge gap research**: Automatically identifies and researches missing information
- **Customizable output**: Supports different output formats and tones
- **Glyph-based synthesis**: Optional advanced synthesis mode using symbolic representation
- **Objective summary evaluation**: More objectively evaluate the quality of individual output summaries

## Installation

```bash
# Install from source
git clone https://github.com/mattjenior/tldr.git
cd tldr
pip install -u .
```

## Requirements

- Python 3.11 or higher
- OpenAI API key (set as environment variable `OPENAI_API_KEY`)

## Usage

### Command Line

```bash
# Basic usage - summarize all text files in current directory
tldr

# Add a specific query
tldr "What are the latest advancements in CRISPR gene editing?"

# Enable automatic query refinement
tldr "CRISPR advances" -r True

# Specify input directory and output directory
tldr -i ./my_papers -o ./summaries

# Enable research agent
tldr -s True

# Use modified output tone
tldr -t modified

# Enable glyph-based synthesis
tldr -g True
```

### Python API

```python
import asyncio
from tldr import TldrClass

# Initialize with a user query
tldr = TldrClass(
    user_query="What are the latest advancements in CRISPR gene editing?",
    search_directory="./my_papers",
    output_directory="./summaries",
    verbose=True
)

# Refine the user query
tldr.refine_user_query()

# Generate document summaries
tldr.all_summaries = asyncio.run(tldr.summarize_resources())

# Integrate summaries across documents
tldr.integrate_summaries()

# Research additional information
tldr.apply_research()

# Polish the final response
tldr.polish_response(output_type="default")
```

### Summary Quality Evaluator

```python
from tldr.summary_judge import SummaryJudge

# Define paths and inputs
content_path = "path/to/original_technical_text.txt"
generated_summary_path = "path/to/summary_text.txt"

# Instantiate the evaluator
judge = SummaryJudge(
    content_path=content_path,
    summary=generated_summary_path)

# Generate objective scoring
score_report = judge.generate_scoring()

# Print results
print(score_report)
```

## Output Files

The tool generates several output files during processing:

- `tldr.summaries.[timestamp].txt`: Individual document summaries
- `tldr.synthesis.[timestamp].txt`: Integrated summary across documents
- `tldr.research.[timestamp].txt`: Additional research information
- `tldr.final.[timestamp].txt`: Final polished response

## Configuration

Configuration is handled through command-line arguments or directly via the API. The system uses a set of carefully crafted prompts defined in `instructions.yaml`.

## License

This project is licensed under the MIT License - see the LICENSE.txt file for details.

## Author

- Matthew Jenior (mattjenior@gmail.com)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
