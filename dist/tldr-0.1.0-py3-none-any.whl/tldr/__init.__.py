from .core import TldrClass
from .tldr import main

__all__ = ['TldrClass', 'main']
